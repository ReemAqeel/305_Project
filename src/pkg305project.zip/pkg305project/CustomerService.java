/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg305project;

/**
 *
 * @author Surface
 */
import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.sql.SQLException;
import java.util.Scanner;

public class CustomerService {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws UnknownHostException, IOException, SQLException {

        try {

// (1) Create Socket obj 
            Socket s = new Socket("127.0.0.1", 8800);

// (2) Create input stream obj (Scanner)
            Scanner in = new Scanner(s.getInputStream());

// (3) Create output stream obj (PrintWriter)
            PrintWriter out = new PrintWriter(s.getOutputStream(), true);

            Scanner userInput = new Scanner(System.in);

            while (true) {

                String str = "";

                str = in.nextLine();

                System.out.println("Customer Service: " + str);

                System.out.print("Enter your request: ");

                str = userInput.nextLine();

//                if (str.equalsIgnoreCase("1")) {
//
//                    
//
//                    out.println(str);
//                } // (4) break if user enters BYE
                 if (str.equalsIgnoreCase("4")) {
                    System.out.println("Thank you Bye :)");
                    break;
                }

            }

// (5) close the socket
            s.close();

        } catch (UnknownHostException e) {

            System.err.println("Host not found");

        } catch (java.net.ConnectException e) {

            System.err.println("There are no connection at this port");

        } catch (IOException e) {

            System.err.println(e.getMessage()
            );

        }

    }

}
