/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg305project;

/**
 *
 * @author Surface
 */
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.SQLException;
import java.util.Scanner;

public class UserRequestes {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException, SQLException {
        // (1) Create ServerSocket obj.

        ServerSocket serverSocket = new ServerSocket(8800);

        System.out.println(
                "Server waiting Connection...");

// (2) Accept Socket 
        Socket clientSocket = serverSocket.accept();

//(3) Return the IP address for the local host
        System.out.println("Client connect via: " + clientSocket.getInetAddress());

// (4) Create input stream obj(Scanner)
        Scanner in = new Scanner(clientSocket.getInputStream()
        );

// (5) Create output stream obj (PrintWriter)
        PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);

        out.println("Welcome, please select your request from the following..");
        
        

        while (in.hasNextLine()) {

            String str = in.nextLine();
//            String username = in.nextLine();
//            String password=in.nextLine();
//            String CourseName=in.nextLine();

            System.out.println("User says: " + str);

            if (str.equalsIgnoreCase("1")) {
                out.println("Please provide us with your username: ");
                    String username = in.nextLine();

                    out.println("Please provide us with your password: ");
                    String password = in.nextLine();

                    out.println("Please write the name of the course: ");

                    String CourseName = in.nextLine();
                    Main cc = new Main();
                    cc.AddCourseQuery(username, password, CourseName);
                

            }else if(str.equalsIgnoreCase("2")){
                out.println("nothing to display");
            }
            else if(str.equalsIgnoreCase("3")){
                out.println("done");
            }
            else if (str.equalsIgnoreCase("4")) {
                System.out.println("Thank you Bye :)");
                break;
            }else
                out.println("Please try again");

            //out.println(str);

        }

// (6) close the socket
        clientSocket.close();

        serverSocket.close();

    }

}
