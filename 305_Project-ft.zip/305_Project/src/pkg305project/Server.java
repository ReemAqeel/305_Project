/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg305project;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 *
 * @author toota mohammed
 */
public class Server {
     private static final int PORT = 1234;
    private static ExecutorService pool = Executors.newFixedThreadPool(4);

    public static void main(String[] args) throws IOException {
        ServerSocket listener = new ServerSocket(PORT);

        while (true) {
            System.out.println("SERVER Waiting for client connection...");
            Socket client = listener.accept();
            System.out.println("SERVER Connected to client!");
            ClientHandler clientThread = new ClientHandler(client);
            pool.execute(clientThread);
        }
    }
}

