
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class ClientHandler implements Runnable {
    private Socket clientSocket;
    private BufferedReader in;
    private PrintWriter out;
    private List<String> clientBasket;

    public ClientHandler(Socket socket) throws IOException {
        this.clientSocket = socket;
        in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
        out = new PrintWriter(clientSocket.getOutputStream(), true);
         clientBasket = new ArrayList<>();
    }

    @Override
    public void run() {
        try {
            String request;
            while ((request = in.readLine()) != null) {
                    // Implement client specific features (like adding courses to basket)
                    out.println("Client Features : ");
                    out.println(" 1- Add Courses in the Backet.");
                    out.println(" 2- Show Courses in the Backet.");
                    out.println(" 3- Bye ");
                    out.println(" Enter your Choice : ");
                    String clientChoice = in.readLine();
                    switch (clientChoice) {
                        case "1":
                            addCourseToBasket();
                            break;
                        case "2":
                            showBasket();
                            break;
                           case "3": 
                               if (request.trim().equals("BYE")) {
                                   break;
                }
                        default:
                            out.println("Invalid choice.");
                            break;
                    }
                }
            }
          catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                in.close();
                out.close();
                clientSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    
        private void addCourseToBasket() throws IOException {
        out.println("Enter the course name to add to your basket, or type 'no' to stop:");
        String courseName;
        while (!(courseName = in.readLine()).equalsIgnoreCase("no")) {
            clientBasket.add(courseName);
            out.println("Course added. Add another course or type 'no' to stop:");
        }
    }
           private void showBasket() {
        if (clientBasket.isEmpty()) {
            out.println("Your basket is empty.");
        } else {
            out.println("Courses in your basket:");
            for (String course : clientBasket) {
                out.println(course);
            }
        }
    }
}